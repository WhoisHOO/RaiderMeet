package com.example.radiermeet2;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

// Junwoo Jang
public class ChatsActivity extends AppCompatActivity {
    //   This class is the implementation of the chats list.


    private static final String USERS_PATH = "Users";
    // This is a path inside the database that holds the info about our users.
    // It gets new data when signing up.
    // Paths are analogous to folder names inside the firebase database

    private static final String CHATS_PATH = "Chats";
    //It is a new path that's only used in the chat parts, and holds
    // the chat contents


    private DrawerLayout drawerLayout;  // a variable to hold a reference to the drawer.


    private final DatabaseReference dbUsers = FirebaseDatabase.getInstance().getReference(USERS_PATH);
    // Use the users path, and get a reference to the database in that path
    private final DatabaseReference dbChats = FirebaseDatabase.getInstance().getReference(CHATS_PATH);

    private final StorageReference storageReference = FirebaseStorage.getInstance().getReference();
    // Get a reference to the storage, which holds our user profile pictures. This is used to download the pictures
    // And show them in the circle image view (The human looking)

    private String userUID;  // contains the logged in user ID.
    private Map<String, Message> chatThreads = new HashMap<>();
    // This Map represents all the chats in the user, it will be used to make the views later
    // in order to show to the user.
    // Key = userID, Value = Last Message


    LinearLayout chatListLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chats);
        // This is a reference to where we would add the chat views, one by one.
        // It is contained within a ScrollView to allow scrolling.




        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            // Check if the user is signed in, otherwise exit
            Toast.makeText(this, "User not signed in, exiting.", Toast.LENGTH_SHORT).show();
            finish();  // Stop creating the activity
            return; // return from onCreate
        }

        userUID = FirebaseAuth.getInstance().getCurrentUser().getUid();
        // get the user ID and put it in userUID
        drawerLayout = findViewById(R.id.drawer_layout);
        // Find the drawer layout for navigation.
        chatListLayout = (LinearLayout) findViewById(R.id.chatListLayout);
        // Find the layout where to add the chats to


        dbChats.orderByKey().startAt(userUID).endAt(userUID+"\uf8ff").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                // The chats database contains all the chats, regardless if it was from/to our user or not.
                // So we need to find the messages that are for our user only, to build our contact list
                // If somebody sent us a message, or we sent him a message, we are contacts.
                // orderByKey: used so we can search the chats database based on the name of the key
                //             it can be user_contact or contact_user, but since we add each message to both
                //             we need to find the keys starting with our userUID. We use startAt and endAt for that.
                // (MessageActivity first and come to this structure)

                for (DataSnapshot child : snapshot.getChildren()) {
                    // For each message thread we get back for our user
                    // Get the child.

                    child.getRef().limitToLast(1).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DataSnapshot> task) {
                            // Get the last message from that thread.
                            if (!task.isSuccessful()) { //This shouldn't happen.
                                Log.e("ChatsActivity", "Error retrieving message!");// Log and ignore
                                return;
                            }

                            for (DataSnapshot child : task.getResult().getChildren()) {
                                // Get to the message itself, which is the child of the data we get.

                                Message lastMsg = child.getValue(Message.class);
                                // Get a Message instance (Message.java) from the class.
                                if (lastMsg == null) {
                                    // Shouldn't happen, but just to make sure
                                    continue;
                                }
                                String contactUID; // Find our contact UID

                                if (lastMsg.recipientUID.equals(userUID)) {
                                    // If we were the recipient of the last message in the conversation
                                    contactUID = lastMsg.senderUID;
                                } else {
                                    contactUID = lastMsg.recipientUID;
                                }

                                chatThreads.put(contactUID, lastMsg);
                                // Add our contactUID (String), last message (Message) to our map.
                            }
                        } // A Map is used so that when we get a new message
                        // we can add it to the hashmap and there won't be duplicates for
                        // that contact, so we wouldn't add him twice, since the key is the
                        // contactUID, only the last message would be updated in that case.

                    });
                }
                updateChatThreads(); // Show the chat threads on the screen.

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) { }
            // Empty Function, i.e. do nothing if the database request was canceled.

        });
    }


    private void updateChatThreads() {  // Show the threads on the screen.


        chatListLayout.removeAllViews();  // Remove old message views


        chatListLayout.postDelayed(new Runnable() {
            @Override
            public void run() {
                showChatThreads();
            } // After the delay, actually show the chats.
        }, 100);
    }  // This is because this function could be called while the database is still responding.

    private void showChatThreads() {
        // This function sorts our contact list with this criteria:
        // Each contact's last message will have a timestamp, the contact associated with the
        // most recent timestamp should be at the top of the chats list.

        ArrayList<String> keys = new ArrayList<>(chatThreads.keySet());
        // Get the keys (user IDS) of our Map into a new array for sorting.
        keys.sort(new Comparator<String>() {
            @Override
            public int compare(String uid1, String uid2) { // Sort based on the most recent timestamp
                Long ts1 = chatThreads.get(uid1).timestamp;
                Long ts2 = chatThreads.get(uid2).timestamp;
                // Use the hashmap to get the last message
                // The keys are user IDs, but we need the timestamp to actually
                // sort them, so look up the last message for each and get the timestamp from it.

                return ts2.compareTo(ts1);
                // sort in reverse order , most recent will have a bigger timestamp.

            }
        });

        for (String uid : keys) {   // Now that it's sorted, for each contact ID

            View chat_item = getLayoutInflater().inflate(R.layout.chat_item, chatListLayout, false);
            // Create the chat_item view.
            chat_item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) { // When this view is clicked,

                    Intent intent = new Intent(getApplicationContext(), MessageActivity.class);
                    // launch the message activity to begin chatting with the contact.
                    intent.putExtra(MessageActivity.EXTRA_CONTACT_UID, uid);
                    // This is where we pass contact UID from the chats activity.
                    startActivity(intent); // start the MessageActivity.

                }
            });
            chatListLayout.addView(chat_item);
            // Add the view before populating the picture, name, and last message
            // So that order is preserved.

            dbUsers.child(uid).get().addOnSuccessListener(new OnSuccessListener<DataSnapshot>() {
                @Override
                public void onSuccess(DataSnapshot dataSnapshot) {
                    User contact = dataSnapshot.getValue(User.class);
                    // Get the User instance (User.java) from the database to get the user's first and last name

                    populateChatThreadLayout(chat_item, contact, chatThreads.get(uid));
                    // This function adds the picture, name, last message after we get them from the database.
                    // The view is already showing on the screen, but we add the information when the database actually replies.

                }
            });
        }
    }

    private View populateChatThreadLayout(View chat_item, User contact, Message lastMsg) {
        TextView textName = chat_item.findViewById(R.id.chat_contact_name); // Name of the contact
        TextView textBrief = chat_item.findViewById(R.id.chat_contact_brief_msg); // Last Message
        CircleImageView img = chat_item.findViewById(R.id.profile_pic);  // Contact Profile image
        textName.setText(contact.getFirstName() + " " + contact.getLastName());  // Set the name to first name + last name
        textBrief.setText(lastMsg.contents); // Set the last message to the contents of the message

        StorageReference pic = storageReference.child("users/" + contact.getuserID() + "/profile.jpg");
        pic.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                final long ONE_MEGABYTE = 1024 * 1024;
                pic.getBytes(2*ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                    @Override
                    public void onSuccess(byte[] bytes) {
                        Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                        img.setImageBitmap(bmp);
                    }
                });

            }
        });
        return chat_item;
    } // Get the picture from the database if it exists, and update it.
    // If it doesn't get updated, the default picture will not be changed.


    /*
    ***************************************************************
    Drawer Menu
     **************************************************************
     */
    public void ClickMenu(View view) {

        Navigation.openDrawer(drawerLayout); //open drawer
    }

    public void ClickLogo(View view) {

        Navigation.closeDrawer(drawerLayout); //close drawer
    }

    public void ClickHome(View view) {

        Navigation.redirectActivity(this, MainActivity.class);
        //Redirect activity to Home
    }

    public void ClickPost(View view) {

        Navigation.redirectActivity(this, PostViewActivity.class);
        //Redirect activity to Post
    }

    public void ClickMessage(View view) {

        recreate();  //Recreate activity
    }

    public void ClickProfile(View view) {

        Navigation.redirectActivity(this, ProfilePage.class);
        //Redirect activity to Profile

    }

    public void ClickFriends(View view){
        //Redirect activity to Friends
        com.example.radiermeet2.Navigation.redirectActivity(this, FriendsActivity.class);
    }

    public void ClickLogout(View view) {

        Navigation.logout(this); //close app

    }

    @Override
    protected void onPause() {
        super.onPause();

        Navigation.closeDrawer(drawerLayout); //close drawer

    }

}