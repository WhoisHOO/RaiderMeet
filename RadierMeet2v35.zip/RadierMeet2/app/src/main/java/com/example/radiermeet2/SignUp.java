package com.example.radiermeet2;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

// android studio library
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

// firebase library
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;


public class SignUp extends AppCompatActivity implements View.OnClickListener{
    // this is for classification, verify email account.
   // public static final String TAG = "MyActivity";
    // To declare texts that are changed by the user
    private EditText edit_text_first_name, edit_text_last_name, edit_text_email, edit_text_password, edit_text_major, edit_text_classification,
            edit_text_gender, edit_text_age, edit_text_hobbies;
    // Declare Button and firebase authentication for store the user data.
    private Button sign_up_user, back_to_sign_in, verify_email_button;
    private FirebaseAuth rAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        rAuth = FirebaseAuth.getInstance();

        sign_up_user =(Button)findViewById(R.id.bt_sign_up);
        sign_up_user.setOnClickListener(this);

        // Back to login page
        back_to_sign_in =(Button)findViewById(R.id.bt_sign_in);
        back_to_sign_in.setOnClickListener(new View.OnClickListener() {
                                         @Override
                                         public void onClick(View view) {
                                             startActivity(new Intent(getApplicationContext(), LoginActivity.class)); }
                                     });
        //Text button for adding new user's information
        edit_text_email =(EditText) findViewById(R.id.et_email);
        edit_text_email.setOnClickListener(this);

        edit_text_first_name =(EditText) findViewById(R.id.et_first_name);
        edit_text_first_name.setOnClickListener(this);

        edit_text_last_name =(EditText) findViewById(R.id.et_last_name);
        edit_text_last_name.setOnClickListener(this);

        edit_text_password =(EditText) findViewById(R.id.et_password);
        edit_text_password.setOnClickListener(this);

        edit_text_major =(EditText) findViewById(R.id.et_major);
        edit_text_major.setOnClickListener(this);

        // the classification part is for checking TTU students.
        // In this moment we couldn't get authorized from the TTU server, so we just left this text button for typing school and student year
        edit_text_classification =(EditText) findViewById(R.id.et_classification);
        edit_text_classification.setOnClickListener(this);

        edit_text_gender =(EditText) findViewById(R.id.et_gender);
        edit_text_gender.setOnClickListener(this);

        edit_text_age =(EditText) findViewById(R.id.et_age);
        edit_text_age.setOnClickListener(this);
        // edit text hooby can type several hobbies in this text button
        edit_text_hobbies =(EditText) findViewById(R.id.et_hobby);
        edit_text_hobbies.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.bt_sign_up:
                user_sign_up();
                break;
        }
    }

    private void user_sign_up(){

        String email= edit_text_email.getText().toString().trim();
        String firstName= edit_text_first_name.getText().toString().trim();
        String lastName= edit_text_last_name.getText().toString().trim();
        String major= edit_text_major.getText().toString().trim();
        String classification= edit_text_classification.getText().toString().trim();
        String gender= edit_text_gender.getText().toString().trim();
        String age= edit_text_age.getText().toString().trim();
        String hobbies= edit_text_hobbies.getText().toString().trim();
        String password= edit_text_password.getText().toString().trim();


        // If user did not type the each string, it shows error messages for request user.
        if(firstName.isEmpty()){
            edit_text_first_name.setError("Please Enter Your First Name.");
            edit_text_first_name.requestFocus();
            return;
        }
        if(lastName.isEmpty()){
            edit_text_last_name.setError("Please Enter Your Last Name.");
            edit_text_last_name.requestFocus();
            return;
        }
        if(email.isEmpty()){
            edit_text_email.setError("Please Enter Your Email for Using RaiderMeet Account.");
            edit_text_email.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            edit_text_email.setError("This Is Not a Valid Email. Please Try It Again.");
            edit_text_email.requestFocus();
            return;
        }

        if(major.isEmpty()){
            edit_text_major.setError("Please Enter a Major.");
            edit_text_major.requestFocus();
            return;
        }

        if(classification.isEmpty()){
            edit_text_major.setError("Please Enter a School Name and Student Year.");
            edit_text_major.requestFocus();
            return;
        }

        if(gender.isEmpty()){
            edit_text_gender.setError("Please Enter a Gender.");
            edit_text_gender.requestFocus();
            return;
        }

        if(age.isEmpty()){
            edit_text_age.setError("Please Enter a Age.");
            edit_text_age.requestFocus();
            return;
        }

        if(hobbies.isEmpty()){
            edit_text_hobbies.setError("Please Enter Your Hobbies.");
            edit_text_hobbies.requestFocus();
            return;
        }
        // This part is for password length, the firebase standard is 6 characters, but we change this 10 characters for making password.
        if(password.length() < 10){
            edit_text_password.setError("You Must Type More than 10 Characters for Password.");
            edit_text_password.requestFocus();
            return;
        }

        // this part is for sending new sign up user information to firebase
        rAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    // we have to follow the order each of text information, if not it makes error.
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            User user = new User(firstName, lastName, email, major,classification, gender, age, hobbies );

                            FirebaseDatabase.getInstance().getReference("Users")
                                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                    .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                // When I use the app, I hate so short message toast.
                                // Therefore, the output message's toast length is long.
                                public void onComplete(@NonNull Task<Void> task) {
                                    if(task.isSuccessful()){
                                        Toast.makeText(SignUp.this, "Welcome RaiderMeet User!", Toast.LENGTH_LONG).show();
                                        startActivity(new Intent(getApplicationContext(),LoginActivity.class));
                                    }
                                    else if(!task.isSuccessful()){
                                        startActivity(new Intent(getApplicationContext(),LoginActivity.class));
                                        Toast.makeText(SignUp.this, "Error! Try It Again.", Toast.LENGTH_LONG).show();
                                        startActivity(new Intent(getApplicationContext(),LoginActivity.class));
                                    }
                                }
                            });
                        }
                        else{
                            startActivity(new Intent(getApplicationContext(),SignUp.class));
                        }
                    }
                });
/*
        // This is verified email then make a email account
        // Connect with TTU server
        final FirebaseUser user = rAuth.getCurrentUser();
        user.sendEmailVerification()
                .addOnCompleteListener(this, new OnCompleteListener(){
            @Override
        public void onComplete(@NonNull Task task) {
                findViewById(R.id.bt_sign_up).setEnabled(true);

                if(task.isSuccessful()) {
                    Toast.makeText(SignUp.this,
                            "Verification email sent to " + user.getEmail(),
                            Toast.LENGTH_LONG).show();
                }
                else{
                    Log.e(TAG, "sendEmailVerification", task.getException());
                    Toast.makeText(SignUp.this,
                            "Failed to send verification email.",
                            Toast.LENGTH_LONG).show();
                }
            }
        });
        */

    }

}