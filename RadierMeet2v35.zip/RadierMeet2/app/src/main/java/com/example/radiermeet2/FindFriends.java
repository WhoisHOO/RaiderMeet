package com.example.radiermeet2;

public class FindFriends {
    public String profileimage, firstName, lastName, major;

    public FindFriends()
    {

    }

    public FindFriends(String profileimage, String firstName, String lastName, String major) {
        this.profileimage = profileimage;
        this.firstName = firstName;
        this.lastName = lastName;
        this.major = major;
    }

    public String getProfileimage() {
        return profileimage;
    }

    public void setProfileimage(String profileimage) {
        this.profileimage = profileimage;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }
}
