package com.example.radiermeet2;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

import de.hdodenhof.circleimageview.CircleImageView;

public class AddFriendsActivity extends AppCompatActivity {

    private ImageButton SearchButton;
    private EditText SearchInputText;
    private RecyclerView SearchResultList;
    private DatabaseReference allUsersDatabaseRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_friends);

        allUsersDatabaseRef = FirebaseDatabase.getInstance().getReference().child("Users");

        SearchResultList = (RecyclerView) findViewById(R.id.Search_Result_List);
        SearchResultList.setHasFixedSize(true);
        SearchResultList.setLayoutManager(new LinearLayoutManager(this));

        SearchButton = (ImageButton) findViewById(R.id.Search_Friends_Button);
        SearchInputText = (EditText) findViewById(R.id.Find_Friends_Search_Box);

        SearchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String searchBoxInput = SearchInputText.getText().toString();
                SearchForFriends(searchBoxInput);
            }
        });

    }

    private void SearchForFriends(String searchBoxInput)
    {
        Toast.makeText(this,"Searching...", Toast.LENGTH_LONG);
        Query searchFriendsQuery = allUsersDatabaseRef.orderByChild("firstName").startAt(searchBoxInput).endAt(searchBoxInput + "\uf8ff");
        FirebaseRecyclerOptions<FindFriends> options =
                new FirebaseRecyclerOptions.Builder<FindFriends>().setQuery(searchFriendsQuery, FindFriends.class).build();

        FirebaseRecyclerAdapter<FindFriends, FindFriendsViewHolder> adapter =
                new FirebaseRecyclerAdapter<FindFriends, FindFriendsViewHolder>(options) {
                    @Override
                    protected void onBindViewHolder(@NonNull FindFriendsViewHolder holder, int position, @NonNull FindFriends model) {
                        holder.firstName.setText(model.getFirstName());
                        holder.lastName.setText(model.getLastName());
                        holder.major.setText(model.getMajor());

                        //Add picasso library to display imgages
                        //Picasso.get().load(model.getProfileimage()).into(holder.profileImage);

                        //used in UserProfileActivity
                        holder.mview.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {

                                //gets id of user that was clicked on after search
                                String visit_user_id = getRef(position).getKey();

                                Intent profileIntent = new Intent(AddFriendsActivity.this,PersonProfileActivity.class);
                                profileIntent.putExtra("visit_user_id", visit_user_id);
                                startActivity(profileIntent);
                            }
                        });
                    }

                    @NonNull
                    @Override
                    public FindFriendsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.all_users_display_layout,parent,false);
                        FindFriendsViewHolder viewHolder = new FindFriendsViewHolder(view);
                        return viewHolder;
                    }
                };
        SearchResultList.setAdapter(adapter);

        adapter.startListening();
    }

    public static class FindFriendsViewHolder extends RecyclerView.ViewHolder
    {
        TextView firstName, lastName, major;
        View mview;
        CircleImageView profileImage;

        public FindFriendsViewHolder(@NonNull View itemView) {
            super(itemView);
            this.mview = itemView;
            firstName = itemView.findViewById(R.id.all_users_profile_first_name);
            lastName = itemView.findViewById(R.id.all_users_profile_last_name);
            major = itemView.findViewById(R.id.all_users_major);

            profileImage = itemView.findViewById(R.id.all_users_profile_image);
        }
    }
}