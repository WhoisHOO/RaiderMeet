package com.example.radiermeet2;

import static android.content.ContentValues.TAG;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class ProfilePage extends AppCompatActivity {
    private Button editProfile;
    private TextView changePic, uploadPic;
    private StorageReference storageReference;
    private StorageReference photoReference;
    private DatabaseReference userRef;
    private FirebaseDatabase database;
    private ImageView profilePicture;
    DrawerLayout drawerLayout;


    TextView userEmail, name, lastname, major, classification, age, gender, hobbies;
    private static final String USERS="Users";
    String email;
    FirebaseUser cUser;
    String uId;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_page);

        //assign variable
        drawerLayout = findViewById(R.id.drawer_layout);

        userEmail=(TextView) findViewById(R.id.email);
        name=(TextView) findViewById(R.id.name);
        major=(TextView) findViewById(R.id.major);
        classification=(TextView) findViewById(R.id.classification);
        age=(TextView) findViewById(R.id.age);
        gender=(TextView) findViewById(R.id.gender);
        hobbies=(TextView) findViewById(R.id.hobbies);
        cUser= FirebaseAuth.getInstance().getCurrentUser();
        uId=cUser.getUid();
        database= FirebaseDatabase.getInstance();
        userRef=database.getReference(USERS);
        profilePicture = findViewById(R.id.profile_pic);
        editProfile = (Button) findViewById(R.id.updatePicButton);
        storageReference = FirebaseStorage.getInstance().getReference();
        photoReference= storageReference.child("users/" + uId + "/profile.jpg");

        userEmail=(TextView) findViewById(R.id.email);
        name=(TextView) findViewById(R.id.name);

        final long ONE_MEGABYTE = 1024 * 1024;
        photoReference.getBytes(2*ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
            @Override
            public void onSuccess(byte[] bytes) {
                Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                profilePicture.setImageBitmap(bmp);

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                //Toast.makeText(getApplicationContext(), "No Such file or Path found!!", Toast.LENGTH_LONG).show();
            }
        });

        userRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                name.setText(dataSnapshot.child(uId).child("firstName").getValue(String.class));
                userEmail.setText(dataSnapshot.child(uId).child("email").getValue(String.class));
                major.setText(dataSnapshot.child(uId).child("major").getValue(String.class));
                classification.setText(dataSnapshot.child(uId).child("classification").getValue(String.class));
                age.setText(dataSnapshot.child(uId).child("age").getValue(String.class));
                gender.setText(dataSnapshot.child(uId).child("gender").getValue(String.class));
                hobbies.setText(dataSnapshot.child(uId).child("hobbies").getValue(String.class));
                Log.i(TAG, "onDataChange:"+ dataSnapshot.child(uId).child("email").getValue(String.class));

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        editProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                com.example.radiermeet2.Navigation.redirectActivity(ProfilePage.this, com.example.radiermeet2.EditProfilePageActivity.class);
            }
        });

    }

    public void ClickMenu(View view){
        //open drawer
        com.example.radiermeet2.Navigation.openDrawer(drawerLayout);
    }

    public void ClickLogo(View view){
        //close drawer
        com.example.radiermeet2.Navigation.closeDrawer(drawerLayout);
    }

    public void ClickHome(View view){
        //Redirect activity to home
        com.example.radiermeet2.Navigation.redirectActivity(this, com.example.radiermeet2.MainActivity.class);
    }

    public void ClickPost(View view){
        //Redirect activity to home
        com.example.radiermeet2.Navigation.redirectActivity(this, com.example.radiermeet2.PostViewActivity.class);
    }

    public void ClickMessage(View view){
        //Redirect activity to Messages
        com.example.radiermeet2.Navigation.redirectActivity(this, com.example.radiermeet2.ChatsActivity.class);
    }

    public void ClickProfile(View view){
        //recreate activity
        recreate();
    }

    public void ClickFriends(View view){
        //Redirect activity to Friends
        com.example.radiermeet2.Navigation.redirectActivity(this, FriendsActivity.class);
    }

    public void ClickLogout(View view){
        //close app
        com.example.radiermeet2.Navigation.logout(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //close drawer
        com.example.radiermeet2.Navigation.closeDrawer(drawerLayout);
    }
}