package com.example.radiermeet2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    private com.example.radiermeet2.MainAdapter.OnItemListener onItemListener;
    DatabaseReference database;
    com.example.radiermeet2.MainAdapter mainAdapter;
    ArrayList<com.example.radiermeet2.User> list;
    FirebaseUser cUser;
    String uId;
    String major, classification, gender, age, hobbies;

    String email;
    DrawerLayout drawerLayout;
    String mEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Assign variable
        drawerLayout = findViewById(R.id.drawer_layout);
        recyclerView = findViewById(R.id.MainRecyclerView);
        database = FirebaseDatabase.getInstance().getReference("Users");
        cUser = FirebaseAuth.getInstance().getCurrentUser();
        uId = cUser.getUid();
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        database.child(uId).child("userID").setValue(uId);

        list = new ArrayList<>();
        onItemListener = new com.example.radiermeet2.MainAdapter.OnItemListener() {
            @Override
            public void onItemClick(View v, int position) {
                Intent intent = new Intent(getApplicationContext(), com.example.radiermeet2.UserProfileActivity.class);
                intent.putExtra("firstName", list.get(position).getFirstName());
                intent.putExtra("lastName", list.get(position).getLastName());
                intent.putExtra("email", list.get(position).getEmail());
                intent.putExtra("major", list.get(position).getMajor());
                intent.putExtra("classification", list.get(position).getClassification());
                intent.putExtra("gender", list.get(position).getGender());
                intent.putExtra("age", list.get(position).getAge());
                intent.putExtra("hobbies", list.get(position).getHobbies());
                intent.putExtra("userID",list.get(position).getuserID());
                startActivity(intent);
            }
        };
        mainAdapter = new com.example.radiermeet2.MainAdapter(this, list, onItemListener);
        recyclerView.setAdapter(mainAdapter);

        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                email = snapshot.child(uId).child("email").getValue(String.class);
                major = snapshot.child(uId).child("major").getValue(String.class);
                classification = snapshot.child(uId).child("classification").getValue(String.class);
                gender = snapshot.child(uId).child("gender").getValue(String.class);
                age = snapshot.child(uId).child("age").getValue(String.class);
                hobbies = snapshot.child(uId).child("hobbies").getValue(String.class);


                for(DataSnapshot dataSnapshot : snapshot.getChildren()){

                    com.example.radiermeet2.User user = dataSnapshot.getValue(com.example.radiermeet2.User.class);
                    mEmail = user.getEmail();
                    if(mEmail != null && mEmail.equals(email))
                        continue;

                }

                mainAdapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    /*
   ***************************************************************
   Drawer Menu
    **************************************************************
    */
    public void ClickMenu(View view){
        //open drawer
        com.example.radiermeet2.Navigation.openDrawer(drawerLayout);
    }

    public void ClickLogo(View view){
        //close drawer
        com.example.radiermeet2.Navigation.closeDrawer(drawerLayout);
    }

    public void ClickHome(View view){
        //Recreate activity
        recreate();
    }

    public void ClickPost(View view){
        //Redirect activity to home
        com.example.radiermeet2.Navigation.redirectActivity(this, com.example.radiermeet2.PostViewActivity.class);
    }

    public void ClickMessage(View view){
        //Redirect activity to Messages
        com.example.radiermeet2.Navigation.redirectActivity(this, com.example.radiermeet2.ChatsActivity.class);
    }

    public void ClickProfile(View view){
        //Redirect activity to Profile
        com.example.radiermeet2.Navigation.redirectActivity(this, ProfilePage.class);
    }

    public void ClickFriends(View view){
        //Redirect activity to Friends
        com.example.radiermeet2.Navigation.redirectActivity(this, FriendsActivity.class);
    }

    public void ClickLogout(View view){
        //close app
        com.example.radiermeet2.Navigation.logout(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //close drawer
        com.example.radiermeet2.Navigation.closeDrawer(drawerLayout);
    }

}